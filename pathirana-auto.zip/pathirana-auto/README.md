# Pathirana Auto

A first runnable workshop management app for a motorcycle service station. It covers customers, motorcycles, job cards, spare parts, invoices, and payments.

## Run locally

Install Python 3.9 or newer. In Terminal:

```sh
cd pathirana-auto
python3 app.py
```

Open **http://127.0.0.1:8000** in a browser. Keep Terminal open while using the app. Stop it with `Ctrl+C`.

No `npm install`, account, or cloud database is needed. The database is created at `data/pathirana.sqlite3` on first launch. This directory is ignored by Git. Back up the entire `data` directory while the app is stopped.

## First use

1. Add a customer and their motorcycle.
2. Create a job card for the motorcycle.
3. Add spare parts to Inventory; receive more stock as needed.
4. Edit the job to set labour, notes, and status. Assign any parts used. The stock count decreases immediately and a stock movement is logged.
5. Issue the invoice from the job card. Its total is locked at this point.
6. Record one or more payments against the invoice.

Prices and balances are in Sri Lankan rupees. They are stored as integer cents to avoid floating point rounding. This early version makes **no tax or discount assumptions**; confirm the applicable tax and invoice requirements with your accountant before real billing.

## Scope and limitations

This is a **local prototype**, bound to `127.0.0.1`. It has no login, staff roles, remote access, synchronization, or automated backups. Use invented or test customer data while evaluating it. Do not expose the server to the internet or enter real customer records until authentication, access control, backups, and deployment are implemented. The database should stay out of GitHub even if the repository is private.

The earlier proposed Next.js + Supabase stack is a reasonable target for a multi-device production system. This dependency-free version makes the workflow visible and testable now. The data model can guide that later migration.

## Verify

```sh
python3 -m unittest discover -s tests -v
```

## Add to your existing GitHub repository

The private repository is currently named `Janiruofficial/Pathirana-Auto-` in the screenshot. Clone it with your signed-in GitHub credentials, copy **the contents of this project folder** into the clone, then commit and push. Leave the existing `.git` directory in the clone untouched. Its `data/` directory must never be committed.
