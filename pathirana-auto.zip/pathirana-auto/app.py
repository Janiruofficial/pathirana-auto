"""Local development server for Pathirana Auto. Python 3.9+, no dependencies."""

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parent
DB = ROOT / "data" / "pathirana.sqlite3"
MAX_BODY = 32_768


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def amount(value, field="amount", allow_zero=True):
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{field} must be a valid number")
    if not number.is_finite() or number < 0 or (not allow_zero and number == 0):
        raise ValueError(f"{field} must be positive" if not allow_zero else f"{field} cannot be negative")
    cents = number * 100
    if cents != cents.to_integral_value() or cents > 999_999_999:
        raise ValueError(f"{field} must have at most two decimal places")
    return int(cents)


def required(data, key, limit=150):
    value = data.get(key, "")
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > limit:
        raise ValueError(f"{key} is required (up to {limit} characters)")
    return value.strip()


def optional(data, key, limit=500):
    value = data.get(key, "")
    if not isinstance(value, str) or len(value.strip()) > limit:
        raise ValueError(f"{key} must be text (up to {limit} characters)")
    return value.strip()


def positive_id(data, key):
    value = data.get(key)
    if isinstance(value, bool):
        raise ValueError(f"{key} must be a positive integer")
    try:
        result = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{key} must be a positive integer")
    if result <= 0 or str(result) != str(value):
        raise ValueError(f"{key} must be a positive integer")
    return result


@contextmanager
def database():
    DB.parent.mkdir(exist_ok=True)
    connection = sqlite3.connect(DB, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 10000")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def init_db():
    with database() as db:
        db.execute("PRAGMA journal_mode = WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS customers (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL,
          email TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS motorcycles (
          id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customers(id),
          registration TEXT NOT NULL COLLATE NOCASE UNIQUE, make TEXT NOT NULL,
          model TEXT NOT NULL, year INTEGER, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS parts (
          id INTEGER PRIMARY KEY, sku TEXT NOT NULL COLLATE NOCASE UNIQUE,
          name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
          price_cents INTEGER NOT NULL CHECK(price_cents >= 0),
          reorder_level INTEGER NOT NULL DEFAULT 0 CHECK(reorder_level >= 0)
        );
        CREATE TABLE IF NOT EXISTS jobs (
          id INTEGER PRIMARY KEY, motorcycle_id INTEGER NOT NULL REFERENCES motorcycles(id),
          complaint TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Open'
            CHECK(status IN ('Open','In progress','Ready','Closed')),
          labour_cents INTEGER NOT NULL DEFAULT 0 CHECK(labour_cents >= 0),
          notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS job_parts (
          id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id),
          part_id INTEGER NOT NULL REFERENCES parts(id), quantity INTEGER NOT NULL CHECK(quantity > 0),
          unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents >= 0)
        );
        CREATE TABLE IF NOT EXISTS invoices (
          id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL UNIQUE REFERENCES jobs(id),
          number TEXT NOT NULL UNIQUE, total_cents INTEGER NOT NULL CHECK(total_cents >= 0),
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS payments (
          id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES invoices(id),
          amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
          method TEXT NOT NULL CHECK(method IN ('Cash','Card','Bank transfer')),
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS stock_movements (
          id INTEGER PRIMARY KEY, part_id INTEGER NOT NULL REFERENCES parts(id),
          change INTEGER NOT NULL CHECK(change != 0), reason TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        """)


def rows(db, sql, params=()):
    return [dict(row) for row in db.execute(sql, params).fetchall()]


def get_or_fail(db, table, record_id):
    if table not in {"customers", "motorcycles", "parts", "jobs", "invoices"}:
        raise ValueError("Invalid table")
    row = db.execute(f"SELECT * FROM {table} WHERE id = ?", (record_id,)).fetchone()
    if row is None:
        raise ValueError(f"{table[:-1].capitalize()} not found")
    return row


def snapshot(db):
    return {
        "customers": rows(db, "SELECT * FROM customers ORDER BY id DESC"),
        "motorcycles": rows(db, """SELECT m.*, c.name AS customer_name FROM motorcycles m
            JOIN customers c ON c.id=m.customer_id ORDER BY m.id DESC"""),
        "parts": rows(db, "SELECT * FROM parts ORDER BY name COLLATE NOCASE"),
        "jobs": rows(db, """SELECT j.*, m.registration, m.make, m.model, c.name AS customer_name,
            COALESCE((SELECT SUM(quantity * unit_price_cents) FROM job_parts WHERE job_id=j.id),0)
            AS parts_cents, EXISTS(SELECT 1 FROM invoices WHERE job_id=j.id) AS invoiced
            FROM jobs j JOIN motorcycles m ON m.id=j.motorcycle_id
            JOIN customers c ON c.id=m.customer_id ORDER BY j.id DESC"""),
        "job_parts": rows(db, """SELECT jp.*, p.name AS part_name, p.sku FROM job_parts jp
            JOIN parts p ON p.id=jp.part_id ORDER BY jp.id"""),
        "invoices": rows(db, """SELECT i.*, j.motorcycle_id, m.registration, c.name AS customer_name,
            COALESCE((SELECT SUM(amount_cents) FROM payments WHERE invoice_id=i.id),0) AS paid_cents
            FROM invoices i JOIN jobs j ON j.id=i.job_id
            JOIN motorcycles m ON m.id=j.motorcycle_id
            JOIN customers c ON c.id=m.customer_id ORDER BY i.id DESC"""),
        "payments": rows(db, "SELECT * FROM payments ORDER BY id DESC"),
        "stock_movements": rows(db, """SELECT sm.*, p.sku, p.name FROM stock_movements sm
            JOIN parts p ON p.id=sm.part_id ORDER BY sm.id DESC LIMIT 50"""),
    }


def create(db, route, data):
    stamp = now()
    if route == "customers":
        cursor = db.execute("INSERT INTO customers(name,phone,email,created_at) VALUES(?,?,?,?)",
                            (required(data, "name"), required(data, "phone", 40),
                             optional(data, "email", 150), stamp))
    elif route == "motorcycles":
        customer_id = positive_id(data, "customer_id")
        get_or_fail(db, "customers", customer_id)
        year = data.get("year")
        if year in (None, ""):
            year = None
        else:
            year = positive_id(data, "year")
            if year < 1900 or year > datetime.now().year + 1:
                raise ValueError("year is out of range")
        cursor = db.execute("""INSERT INTO motorcycles(customer_id,registration,make,model,year,created_at)
            VALUES(?,?,?,?,?,?)""", (customer_id, required(data, "registration", 30).upper(),
                                     required(data, "make", 80), required(data, "model", 80), year, stamp))
    elif route == "parts":
        quantity = data.get("quantity", 0)
        reorder = data.get("reorder_level", 0)
        if isinstance(quantity, bool) or isinstance(reorder, bool):
            raise ValueError("Stock values must be whole numbers")
        try:
            quantity, reorder = int(quantity), int(reorder)
        except (TypeError, ValueError):
            raise ValueError("Stock values must be whole numbers")
        if quantity < 0 or reorder < 0 or str(quantity) != str(data.get("quantity", 0)) or str(reorder) != str(data.get("reorder_level", 0)):
            raise ValueError("Stock values must be non-negative whole numbers")
        cursor = db.execute("INSERT INTO parts(sku,name,quantity,price_cents,reorder_level) VALUES(?,?,?,?,?)",
                            (required(data, "sku", 50).upper(), required(data, "name"), quantity,
                             amount(data.get("price", 0), "price"), reorder))
        if quantity:
            db.execute("INSERT INTO stock_movements(part_id,change,reason,created_at) VALUES(?,?,?,?)",
                       (cursor.lastrowid, quantity, "Opening balance", stamp))
    elif route == "jobs":
        bike_id = positive_id(data, "motorcycle_id")
        get_or_fail(db, "motorcycles", bike_id)
        cursor = db.execute("INSERT INTO jobs(motorcycle_id,complaint,created_at) VALUES(?,?,?)",
                            (bike_id, required(data, "complaint", 1000), stamp))
    elif route == "job-parts":
        job_id, part_id = positive_id(data, "job_id"), positive_id(data, "part_id")
        job, part = get_or_fail(db, "jobs", job_id), get_or_fail(db, "parts", part_id)
        if job["status"] == "Closed" or db.execute("SELECT 1 FROM invoices WHERE job_id=?", (job_id,)).fetchone():
            raise ValueError("This job is closed or invoiced")
        quantity = positive_id(data, "quantity")
        changed = db.execute("UPDATE parts SET quantity=quantity-? WHERE id=? AND quantity>=?",
                             (quantity, part_id, quantity)).rowcount
        if not changed:
            raise ValueError(f"Only {part['quantity']} in stock")
        cursor = db.execute("INSERT INTO job_parts(job_id,part_id,quantity,unit_price_cents) VALUES(?,?,?,?)",
                            (job_id, part_id, quantity, part["price_cents"]))
        db.execute("INSERT INTO stock_movements(part_id,change,reason,created_at) VALUES(?,?,?,?)",
                   (part_id, -quantity, f"Job #{job_id}", stamp))
    elif route == "stock":
        part_id = positive_id(data, "part_id")
        get_or_fail(db, "parts", part_id)
        quantity = positive_id(data, "quantity")
        cursor = db.execute("UPDATE parts SET quantity=quantity+? WHERE id=?", (quantity, part_id))
        db.execute("INSERT INTO stock_movements(part_id,change,reason,created_at) VALUES(?,?,?,?)",
                   (part_id, quantity, required(data, "reason", 150), stamp))
    elif route == "invoices":
        job_id = positive_id(data, "job_id")
        job = get_or_fail(db, "jobs", job_id)
        if db.execute("SELECT 1 FROM invoices WHERE job_id=?", (job_id,)).fetchone():
            raise ValueError("This job already has an invoice")
        parts_total = db.execute("SELECT COALESCE(SUM(quantity*unit_price_cents),0) FROM job_parts WHERE job_id=?",
                                 (job_id,)).fetchone()[0]
        total = parts_total + job["labour_cents"]
        cursor = db.execute("INSERT INTO invoices(job_id,number,total_cents,created_at) VALUES(?,?,?,?)",
                            (job_id, f"PA-{job_id:06d}", total, stamp))
    elif route == "payments":
        invoice_id = positive_id(data, "invoice_id")
        invoice = get_or_fail(db, "invoices", invoice_id)
        paid = db.execute("SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE invoice_id=?",
                          (invoice_id,)).fetchone()[0]
        value = amount(data.get("amount"), allow_zero=False)
        if value > invoice["total_cents"] - paid:
            raise ValueError("Payment exceeds the outstanding balance")
        method = required(data, "method", 30)
        if method not in {"Cash", "Card", "Bank transfer"}:
            raise ValueError("Invalid payment method")
        cursor = db.execute("INSERT INTO payments(invoice_id,amount_cents,method,created_at) VALUES(?,?,?,?)",
                            (invoice_id, value, method, stamp))
    else:
        raise ValueError("Unknown action")
    return cursor.lastrowid


def update_job(db, job_id, data):
    job = get_or_fail(db, "jobs", job_id)
    if db.execute("SELECT 1 FROM invoices WHERE job_id=?", (job_id,)).fetchone():
        raise ValueError("An invoiced job cannot be edited")
    status = required(data, "status", 30)
    if status not in {"Open", "In progress", "Ready", "Closed"}:
        raise ValueError("Invalid status")
    db.execute("UPDATE jobs SET status=?,labour_cents=?,notes=? WHERE id=?",
               (status, amount(data.get("labour", 0), "labour"), optional(data, "notes", 2000), job_id))


def remove_job_part(db, line_id):
    line = db.execute("SELECT * FROM job_parts WHERE id=?", (line_id,)).fetchone()
    if line is None:
        raise ValueError("Job part not found")
    job = get_or_fail(db, "jobs", line["job_id"])
    if job["status"] == "Closed" or db.execute("SELECT 1 FROM invoices WHERE job_id=?", (job["id"],)).fetchone():
        raise ValueError("This job is closed or invoiced")
    db.execute("DELETE FROM job_parts WHERE id=?", (line_id,))
    db.execute("UPDATE parts SET quantity=quantity+? WHERE id=?", (line["quantity"], line["part_id"]))
    db.execute("INSERT INTO stock_movements(part_id,change,reason,created_at) VALUES(?,?,?,?)",
               (line["part_id"], line["quantity"], f"Returned from job #{job['id']}", now()))


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/state":
            with database() as db:
                return self.respond(200, snapshot(db))
        files = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
                 "/styles.css": ("styles.css", "text/css")}
        if path not in files:
            return self.send_error(404)
        file_path = ROOT / "web" / files[path][0]
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", files[path][1] + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        self.mutate("POST")

    def do_PATCH(self):
        self.mutate("PATCH")

    def do_DELETE(self):
        self.mutate("DELETE")

    def mutate(self, method):
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > MAX_BODY:
                return self.respond(413, {"error": "Request too large"})
            data = {} if method == "DELETE" else json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError("Expected a JSON object")
            with database() as db:
                db.execute("BEGIN IMMEDIATE")
                if method == "POST" and path.startswith("/api/"):
                    record_id = create(db, path[5:], data)
                elif method == "PATCH" and path.startswith("/api/jobs/"):
                    record_id = int(path.split("/")[-1])
                    if record_id <= 0:
                        raise ValueError("Invalid job ID")
                    update_job(db, record_id, data)
                elif method == "DELETE" and path.startswith("/api/job-parts/"):
                    record_id = int(path.split("/")[-1])
                    if record_id <= 0:
                        raise ValueError("Invalid job part ID")
                    remove_job_part(db, record_id)
                else:
                    return self.respond(404, {"error": "Unknown endpoint"})
            self.respond(200, {"id": record_id})
        except (ValueError, json.JSONDecodeError) as exc:
            self.respond(400, {"error": str(exc)})
        except sqlite3.IntegrityError as exc:
            message = "Duplicate registration or SKU, or invalid data"
            self.respond(409, {"error": message})


if __name__ == "__main__":
    init_db()
    print("Pathirana Auto: http://127.0.0.1:8000", flush=True)
    ThreadingHTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
