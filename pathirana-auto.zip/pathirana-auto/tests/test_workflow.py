import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import app


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.patch = patch.object(app, "DB", Path(self.temp.name) / "test.sqlite3")
        self.patch.start()
        app.init_db()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_stock_and_payment_invariants(self):
        with app.database() as db:
            customer = app.create(db, 'customers', {'name':'Test Customer','phone':'0771234567'})
            bike = app.create(db, 'motorcycles', {'customer_id':customer,'registration':'WP-1234','make':'Honda','model':'Dio'})
            part = app.create(db, 'parts', {'sku':'OIL-1','name':'Oil','quantity':'3','price':'1250.50','reorder_level':'1'})
            job = app.create(db, 'jobs', {'motorcycle_id':bike,'complaint':'Annual service'})
            app.update_job(db, job, {'status':'In progress','labour':'2000.00','notes':'Checked brakes'})
            line = app.create(db, 'job-parts', {'job_id':job,'part_id':part,'quantity':'2'})
            self.assertEqual(app.snapshot(db)['parts'][0]['quantity'], 1)
            with self.assertRaisesRegex(ValueError, 'Only 1 in stock'):
                app.create(db, 'job-parts', {'job_id':job,'part_id':part,'quantity':'2'})
            app.remove_job_part(db, line)
            self.assertEqual(app.snapshot(db)['parts'][0]['quantity'], 3)
            app.create(db, 'job-parts', {'job_id':job,'part_id':part,'quantity':'2'})
            invoice = app.create(db, 'invoices', {'job_id':job})
            self.assertEqual(app.snapshot(db)['invoices'][0]['total_cents'], 450100)
            with self.assertRaisesRegex(ValueError, 'already has an invoice'):
                app.create(db, 'invoices', {'job_id':job})
            with self.assertRaisesRegex(ValueError, 'cannot be edited'):
                app.update_job(db, job, {'status':'Ready','labour':'1'})
            app.create(db, 'payments', {'invoice_id':invoice,'amount':'1000','method':'Cash'})
            with self.assertRaisesRegex(ValueError, 'exceeds'):
                app.create(db, 'payments', {'invoice_id':invoice,'amount':'4000','method':'Card'})
            self.assertEqual(app.snapshot(db)['invoices'][0]['paid_cents'], 100000)
        with app.database() as reopened:
            self.assertEqual(app.snapshot(reopened)['invoices'][0]['total_cents'], 450100)

    def test_validation_and_uniqueness(self):
        with app.database() as db:
            app.create(db, 'parts', {'sku':'ABC','name':'Filter','quantity':'0','price':'12.50'})
            with self.assertRaises(ValueError):
                app.create(db, 'parts', {'sku':'DEF','name':'Filter','quantity':'-1','price':'12.50'})
            with self.assertRaises(ValueError):
                app.create(db, 'parts', {'sku':'DEF','name':'Filter','quantity':'1','price':'12.505'})


if __name__ == '__main__':
    unittest.main()
