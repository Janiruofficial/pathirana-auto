const NAV = [
  ['dashboard', '◫', 'Dashboard'], ['customers', '♙', 'Customers'],
  ['motorcycles', '◈', 'Motorcycles'], ['jobs', '▤', 'Job cards'],
  ['parts', '▦', 'Inventory'], ['invoices', '▣', 'Invoices']
];
const $ = selector => document.querySelector(selector);
const safe = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = cents => 'LKR ' + (Number(cents || 0) / 100).toLocaleString('en-LK', {minimumFractionDigits:2,maximumFractionDigits:2});
const date = iso => new Date(iso).toLocaleDateString('en-LK', {day:'numeric',month:'short',year:'numeric'});
const empty = (title, message) => `<div class="empty"><b>${safe(title)}</b>${safe(message)}</div>`;
let state = null, page = 'dashboard', query = '';

function toast(message, error = false) {
  const node = $('#notice'); node.textContent = message; node.className = error ? 'error' : '';
  clearTimeout(toast.timer); toast.timer = setTimeout(() => { node.textContent = ''; }, 5500);
}
async function refresh() {
  const response = await fetch('/api/state');
  if (!response.ok) throw new Error('Cannot load workshop data');
  state = await response.json(); render();
}
async function send(route, data, method = 'POST') {
  const response = await fetch('/api/' + route, {method,headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Could not save');
  await refresh(); toast('Saved successfully'); return result;
}
function panel(title, subtitle, body, action='') {
  return `<div class="panel"><div class="panel-head"><div><h2>${title}</h2><p>${subtitle}</p></div>${action}</div>${body}</div>`;
}
function table(headings, body) {
  return `<div class="table-wrap"><table><thead><tr>${headings.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table></div>`;
}
const badge = status => `<span class="badge ${status==='In progress'?'progress':status==='Ready'?'ready':status==='Closed'?'closed':''}">${safe(status)}</span>`;
const b = (label, action, id) => `<button type="button" class="text-button" data-action="${action}" data-id="${id}">${label}</button>`;
function selectOptions(items, label) { return items.map(item=>`<option value="${item.id}">${safe(label(item))}</option>`).join(''); }
function matches(...values) {return values.some(value=>String(value ?? '').toLowerCase().includes(query));}

function dashboard() {
  const active = state.jobs.filter(j=>j.status!=='Closed');
  const low = state.parts.filter(p=>p.quantity<=p.reorder_level);
  const balance = state.invoices.reduce((sum,i)=>sum+i.total_cents-i.paid_cents,0);
  const cards = [
    ['Open job cards',active.length,'Currently in the workshop','▤'],
    ['Ready for pickup',active.filter(j=>j.status==='Ready').length,'Waiting for collection','↗'],
    ['Low stock items',low.length,'At or below reorder level','▦'],
    ['Outstanding',money(balance),'Unpaid invoice balance','◉']
  ];
  const stats = `<div class="grid-stats">${cards.map(([title,value,desc,icon])=>`<div class="stat"><div class="label">${title}<span class="symbol">${icon}</span></div><strong>${value}</strong><small>${desc}</small></div>`).join('')}</div>`;
  const jobRows = active.slice(0,6).map(j=>`<tr><td><strong>#${j.id}</strong><small>${date(j.created_at)}</small></td><td><strong>${safe(j.registration)}</strong><small>${safe(j.make)} ${safe(j.model)}</small></td><td>${safe(j.customer_name)}</td><td>${badge(j.status)}</td><td>${b('View','job',j.id)}</td></tr>`).join('');
  const jobs = panel('Active job cards','Your current workshop queue',jobRows?table(['Job','Motorcycle','Customer','Status',''],jobRows):empty('No active jobs','Create a job card to start tracking work.'),`<button class="link" data-page="jobs">View all →</button>`);
  const lowRows = low.slice(0,6).map(p=>`<div class="summary-line"><div><strong>${safe(p.name)}</strong><small style="display:block;color:#8b998d">${safe(p.sku)}</small></div><span class="badge low">${p.quantity} left</span></div>`).join('');
  const stock = panel('Stock attention','Items to reorder',lowRows||empty('Stock looks good','Nothing is below its reorder level.'),`<button class="link" data-page="parts">Inventory →</button>`);
  return stats + `<div class="two-col">${jobs}${stock}</div>`;
}

function customers() {
  const list = state.customers.filter(c=>matches(c.name,c.phone,c.email));
  const content = list.length?table(['Customer','Contact','Motorcycles','Added',''],list.map(c=>`<tr><td><strong>${safe(c.name)}</strong></td><td>${safe(c.phone)}<small>${safe(c.email)}</small></td><td>${state.motorcycles.filter(m=>m.customer_id===c.id).length}</td><td>${date(c.created_at)}</td><td>${b('Add motorcycle','bike-for',c.id)}</td></tr>`).join('')):empty('No customers found','Add a customer or change the search.');
  return section('Customer records',`${state.customers.length} total customers`,'Add customer','customer',content);
}
function motorcycles() {
  const list=state.motorcycles.filter(m=>matches(m.registration,m.make,m.model,m.customer_name));
  const content=list.length?table(['Registration','Motorcycle','Owner','Jobs',''],list.map(m=>`<tr><td><strong>${safe(m.registration)}</strong></td><td>${safe(m.make)} ${safe(m.model)}<small>${m.year || 'Year unspecified'}</small></td><td>${safe(m.customer_name)}</td><td>${state.jobs.filter(j=>j.motorcycle_id===m.id).length}</td><td>${b('New job','job-for',m.id)}</td></tr>`).join('')):empty('No motorcycles found','Add a motorcycle after adding its owner.');
  return section('Motorcycle records',`${state.motorcycles.length} registered motorcycles`,'Add motorcycle','bike',content);
}
function jobs() {
  const list=state.jobs.filter(j=>matches(j.id,j.registration,j.customer_name,j.complaint,j.status));
  const content=list.length?table(['Job','Motorcycle / owner','Reported issue','Charges','Status',''],list.map(j=>`<tr><td><strong>#${j.id}</strong><small>${date(j.created_at)}</small></td><td><strong>${safe(j.registration)}</strong><small>${safe(j.customer_name)}</small></td><td title="${safe(j.complaint)}">${safe(j.complaint.slice(0,55))}${j.complaint.length>55?'…':''}</td><td>${money(j.labour_cents+j.parts_cents)}</td><td>${badge(j.status)}</td><td>${b('Open','job',j.id)}</td></tr>`).join('')):empty('No job cards found','Create a job card for a motorcycle.');
  return section('Workshop job cards',`${state.jobs.length} jobs recorded`,'New job card','job-new',content);
}
function parts() {
  const list=state.parts.filter(p=>matches(p.sku,p.name));
  const content=list.length?table(['Part','SKU','Stock','Selling price','Reorder at',''],list.map(p=>`<tr><td><strong>${safe(p.name)}</strong></td><td>${safe(p.sku)}</td><td>${p.quantity<=p.reorder_level?`<span class="badge low">${p.quantity} · Low</span>`:p.quantity}</td><td>${money(p.price_cents)}</td><td>${p.reorder_level}</td><td>${b('Receive stock','restock',p.id)}</td></tr>`).join('')):empty('No parts found','Add a part to start stock tracking.');
  const movements=state.stock_movements.slice(0,6).map(m=>`<div class="activity"><span class="activity-icon">${m.change>0?'＋':'−'}</span><div><p>${safe(m.name)} · ${m.change>0?'+':''}${m.change}</p><small>${safe(m.reason)} · ${date(m.created_at)}</small></div></div>`).join('');
  return section('Spare parts',`${state.parts.length} catalogued parts`,'Add part','part',content)+panel('Recent stock movements','Every stock change is recorded',movements||empty('No movements yet','Stock activity will appear here.'));
}
function invoices() {
  const filtered=state.invoices.filter(i=>matches(i.number,i.customer_name,i.registration));
  const content=filtered.map(i=>`<div class="invoice-card"><div><strong>${safe(i.number)}</strong> ${i.paid_cents===i.total_cents?'<span class="badge ready">Paid</span>':'<span class="badge progress">Balance due</span>'}<p>${safe(i.customer_name)} · ${safe(i.registration)} · ${date(i.created_at)}</p>${b('View invoice','invoice',i.id)}</div><div class="total">${money(i.total_cents)}<small>${money(i.total_cents-i.paid_cents)} outstanding</small></div></div>`).join('');
  return section('Invoices & payments',`${state.invoices.length} invoices issued`,null,null,content||empty('No invoices found','Create an invoice from a job card.'));
}
function section(title, subtitle, button, action, content) {
  return `<div class="section-bar"><p>${safe(subtitle)}</p><div class="toolbar"><input class="search" id="search" type="search" placeholder="Search ${safe(title.toLowerCase())}…" value="${safe(query)}" aria-label="Search">${button?`<button class="button primary" data-action="${action}">＋ ${button}</button>`:''}</div></div>${panel(title,'',content)}`;
}
function jobDetail(id) {
  const j=state.jobs.find(x=>x.id===id); if(!j) return jobs();
  const used=state.job_parts.filter(x=>x.job_id===id);
  const invoice=state.invoices.find(x=>x.job_id===id);
  const partRows=used.map(p=>`<tr><td><strong>${safe(p.part_name)}</strong><small>${safe(p.sku)}</small></td><td>${p.quantity}</td><td>${money(p.unit_price_cents)}</td><td>${money(p.unit_price_cents*p.quantity)}</td><td>${!invoice&&j.status!=='Closed'?b('Return','return-part',p.id):''}</td></tr>`).join('');
  const buttons=invoice?b('View invoice','invoice',invoice.id):`${b('Edit job','edit-job',id)} ${j.status!=='Closed'?b('Use part','use-part',id):''} <button class="button primary" data-action="make-invoice" data-id="${id}">Create invoice</button>`;
  return `<button class="text-button" data-page="jobs">← All job cards</button><div class="section-bar"><div><h2>Job card #${j.id}</h2><p>${safe(j.registration)} · ${safe(j.make)} ${safe(j.model)} · ${safe(j.customer_name)}</p></div><div class="toolbar">${buttons}</div></div><div class="two-col"><div>${panel('Parts used','Stock is deducted when assigned',partRows?table(['Part','Qty','Unit price','Total',''],partRows):empty('No parts assigned','Add parts as you use them.'))}${panel('Reported issue','Customer description',`<p>${safe(j.complaint)}</p><p style="white-space:pre-wrap;color:#748277">${safe(j.notes||'No work notes yet.')}</p>`)}</div><div>${panel('Job summary',`Opened ${date(j.created_at)}`,`<div class="summary-line"><span>Status</span>${badge(j.status)}</div><div class="summary-line"><span>Labour</span><strong>${money(j.labour_cents)}</strong></div><div class="summary-line"><span>Parts</span><strong>${money(j.parts_cents)}</strong></div><div class="summary-line"><strong>Total</strong><strong>${money(j.labour_cents+j.parts_cents)}</strong></div>${invoice?'<p class="hint">Invoice issued. Charges are locked.</p>':''}`)}</div></div>`;
}
function invoiceDetail(id) {
  const i=state.invoices.find(x=>x.id===id); if(!i) return invoices();
  const job=state.jobs.find(x=>x.id===i.job_id), parts=state.job_parts.filter(x=>x.job_id===i.job_id), pays=state.payments.filter(x=>x.invoice_id===id);
  const lines=parts.map(p=>`<tr><td>${safe(p.part_name)} × ${p.quantity}</td><td>${money(p.unit_price_cents*p.quantity)}</td></tr>`).join('')+`<tr><td>Labour</td><td>${money(job.labour_cents)}</td></tr>`;
  return `<button class="text-button" data-page="invoices">← All invoices</button><div class="section-bar"><div><h2>Invoice ${safe(i.number)}</h2><p>${safe(i.customer_name)} · ${safe(i.registration)} · ${date(i.created_at)}</p></div><div class="toolbar">${i.total_cents>i.paid_cents?`<button class="button primary" data-action="payment" data-id="${id}">Record payment</button>`:''}<button class="button secondary" onclick="window.print()">Print</button></div></div><div class="two-col"><div>${panel('Invoice lines','Recorded at the time of issue',table(['Description','Amount'],lines))}</div><div>${panel('Payment summary','Amounts in Sri Lankan rupees',`<div class="summary-line"><span>Invoice total</span><strong>${money(i.total_cents)}</strong></div><div class="summary-line"><span>Paid</span><strong>${money(i.paid_cents)}</strong></div><div class="summary-line"><strong>Balance due</strong><strong>${money(i.total_cents-i.paid_cents)}</strong></div>${pays.map(p=>`<div class="activity"><span class="activity-icon">✓</span><div><p>${money(p.amount_cents)} · ${safe(p.method)}</p><small>${date(p.created_at)}</small></div></div>`).join('')}`)}</div></div>`;
}
function render() {
  $('#nav').innerHTML=NAV.map(([name,icon,label])=>`<button type="button" data-page="${name}" class="${page===name?'active':''}"><span class="icon">${icon}</span>${label}</button>`).join('');
  const titles={dashboard:['OVERVIEW','Workshop overview'],customers:['PEOPLE','Customers'],motorcycles:['VEHICLES','Motorcycles'],jobs:['WORKSHOP','Job cards'],parts:['INVENTORY','Parts & stock'],invoices:['BILLING','Invoices & payments']};
  $('#section-label').textContent=titles[page][0]; $('#heading').textContent=titles[page][1];
  $('#content').innerHTML=({dashboard,customers,motorcycles,jobs,parts,invoices}[page])();
}
function navigate(next) {page=next;query='';render();window.scrollTo(0,0);}

function field(name,label,type='text',value='',extra='required') {
  return `<label class="field">${label}<input name="${name}" type="${type}" value="${safe(value)}" ${extra}></label>`;
}
function pick(name,label,items,selected) {
  return `<label class="field">${label}<select name="${name}" required>${items.map(([value,text])=>`<option value="${safe(value)}" ${String(value)===String(selected)?'selected':''}>${safe(text)}</option>`).join('')}</select></label>`;
}
function textarea(name,label,value='') {return `<label class="field">${label}<textarea name="${name}">${safe(value)}</textarea></label>`;}
function openForm(title, html, route, method='POST', callback) {
  $('#modal-title').textContent=title; $('#modal-fields').innerHTML=html;
  $('#modal-form').onsubmit=async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget));const button=event.currentTarget.querySelector('[type=submit]');button.disabled=true;
    try{const result=await send(route,data,method);$('#modal').close();if(callback)callback(result);}catch(error){toast(error.message,true);}finally{button.disabled=false;}};
  $('#modal').showModal();
}
function form(action,id) {
  if(action==='customer') return openForm('Add customer',field('name','Full name')+field('phone','Phone number','tel')+field('email','Email (optional)','email','',''), 'customers');
  if(action==='bike'||action==='bike-for') {
    if(!state.customers.length)return toast('Add a customer first',true);
    return openForm('Add motorcycle',pick('customer_id','Owner',state.customers.map(c=>[c.id,`${c.name} · ${c.phone}`]),id)+field('registration','Registration number')+field('make','Make')+field('model','Model')+field('year','Year (optional)','number','','min="1900"'),'motorcycles');
  }
  if(action==='job-new'||action==='job-for') {
    if(!state.motorcycles.length)return toast('Add a customer and motorcycle first',true);
    return openForm('New job card',pick('motorcycle_id','Motorcycle',state.motorcycles.map(m=>[m.id,`${m.registration} · ${m.customer_name}`]),id)+textarea('complaint','Reported issue'),'jobs','POST',result=>{navigate('jobs');showDetail('job',result.id);});
  }
  if(action==='part')return openForm('Add spare part',field('sku','SKU / part code')+field('name','Part name')+field('quantity','Opening quantity','number',0,'required min="0" step="1"')+field('price','Selling price (LKR)','number',0,'required min="0" step="0.01"')+field('reorder_level','Reorder level','number',0,'required min="0" step="1"'),'parts');
  if(action==='restock')return openForm('Receive stock',`<p class="hint">${safe(state.parts.find(p=>p.id===id)?.name)}</p><input type="hidden" name="part_id" value="${id}">`+field('quantity','Quantity received','number',1,'required min="1" step="1"')+field('reason','Reason / supplier reference','','Stock received'),'stock');
  if(action==='edit-job') {
    const j=state.jobs.find(x=>x.id===id);
    return openForm(`Edit job #${id}`,pick('status','Status',['Open','In progress','Ready','Closed'].map(s=>[s,s]),j.status)+field('labour','Labour charge (LKR)','number',(j.labour_cents/100).toFixed(2),'required min="0" step="0.01"')+textarea('notes','Work notes',j.notes),`jobs/${id}`,'PATCH',()=>showDetail('job',id));
  }
  if(action==='use-part') {
    const available=state.parts.filter(p=>p.quantity>0);
    if(!available.length)return toast('Add stock before assigning a part',true);
    return openForm(`Use part · job #${id}`,`<input type="hidden" name="job_id" value="${id}">`+pick('part_id','Part',available.map(p=>[p.id,`${p.name} · ${p.quantity} in stock · ${money(p.price_cents)}`]))+field('quantity','Quantity used','number',1,'required min="1" step="1"'),'job-parts','POST',()=>showDetail('job',id));
  }
  if(action==='payment') {
    const i=state.invoices.find(x=>x.id===id), balance=(i.total_cents-i.paid_cents)/100;
    return openForm(`Payment · ${i.number}`,`<p class="hint">Outstanding: ${money(i.total_cents-i.paid_cents)}</p><input type="hidden" name="invoice_id" value="${id}">`+field('amount','Amount received (LKR)','number',balance.toFixed(2),`required min="0.01" max="${balance.toFixed(2)}" step="0.01"`)+pick('method','Payment method',['Cash','Card','Bank transfer'].map(s=>[s,s])),'payments','POST',()=>showDetail('invoice',id));
  }
}
function showDetail(type,id){$('#content').innerHTML=type==='job'?jobDetail(id):invoiceDetail(id);window.scrollTo(0,0);}
document.addEventListener('click',async event=>{
  const target=event.target.closest('[data-page],[data-action]');if(!target)return;
  if(target.dataset.page)return navigate(target.dataset.page);
  const action=target.dataset.action,id=Number(target.dataset.id);
  if(action==='job'||action==='invoice')return showDetail(action,id);
  if(action==='return-part') {
    const line=state.job_parts.find(x=>x.id===id);
    if(!line||!confirm(`Return ${line.quantity} × ${line.part_name} to stock?`))return;
    try{await send(`job-parts/${id}`,{},'DELETE');showDetail('job',line.job_id);}catch(error){toast(error.message,true);}return;
  }
  if(action==='make-invoice') {
    if(!confirm(`Issue an invoice for job #${id}? Charges will be locked.`))return;
    try{const result=await send('invoices',{job_id:id});navigate('invoices');showDetail('invoice',result.id);}catch(error){toast(error.message,true);}return;
  }
  form(action,id);
});
document.addEventListener('input',event=>{if(event.target.id==='search'){const start=event.target.selectionStart;query=event.target.value.toLowerCase();render();const input=$('#search');input.focus();input.setSelectionRange(start,start);}});
$('#new-job').onclick=()=>form('job-new');$('#close-modal').onclick=$('#cancel-modal').onclick=()=>$('#modal').close();
$('#today').textContent=new Date().toLocaleDateString('en-LK',{weekday:'short',day:'numeric',month:'long',year:'numeric'});
refresh().catch(error=>toast(error.message,true));
