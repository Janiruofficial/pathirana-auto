PATHIRANA AUTO — OPENING THE APP

1. Keep every file in this folder together.
2. Double-click "OPEN PATHIRANA AUTO.html".
3. Safari opens the workshop app.

No Python, Terminal, Xcode, installation, or internet connection is required.

YOUR DATA

The app saves records inside the browser on this Mac. Use the Backup button
regularly and keep the downloaded JSON backup somewhere safe. Use Restore to
load that file again. Clearing Safari website data or moving to another browser
can remove the browser copy, so backups matter.

For now, open the app from the same HTML file and use the same browser each time.
This version is intended for testing the workflow. Before using real customer
records on several devices, the app needs accounts, a shared online database,
access permissions, and automatic backups.

GITHUB

Upload these files themselves to the repository, rather than uploading the ZIP:

- index.html
- app.js
- styles.css
- README.txt

The file named "OPEN PATHIRANA AUTO.html" is included for easy local opening.
